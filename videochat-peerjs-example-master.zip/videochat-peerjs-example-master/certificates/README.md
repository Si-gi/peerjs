# Certificates for SSL

This certificates are public and they will be used by Express and PeerJS to create an HTTPS connection. They are not meant to be used in production obviously.
